# assignment-5-base

Base repo for assignment 5


Implement Tree Search.

Github Link: https://classroom.github.com/a/uTMecGsc (Links to an external site.)

Instructions:

1. Template repo has a node.js file.

2. Implement the search method as per the method documentation.

3. Method documentation is available as comments.

4. Both iterative and recursive solutions are acceptable.


Shreyas Redij: 001053076