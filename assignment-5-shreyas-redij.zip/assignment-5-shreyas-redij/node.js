/**
* A Node represents an HTML Element. A node can have a tag name,
* a list of CSS classes and a list of children nodes and id associated with that...
*/
class Node {

  // constructor(tag,classes,children) {
  //   // Tag name of the node.
  //   this.tag = tag;
  //   // Array of CSS class names (string) on this element.
  //   this.classes = classes;
  //   // Array of child nodes.
  //   this.children = children; // All children are of type Node
  // }

  constructor(tag, id, classes, children) {
    // Tag name of the node.
    this.tag = tag;
    // Array of CSS class names (string) on this element.
    this.id = id;
    //string
    this.classes = classes;
    // Array of children nodes.
    this.children = children;

    // All children are of type Node
  }
  
  /**
  * Returns descendent nodes matching the selector. Selector can be 
  * a tag name or a CSS class name.
  * 
  * For example: 
  * 
  * 1.
  * <div> 
  *   <span id="span-1"></span>
  *   <span id="span-2"></span>
  *   <div>
  *     <span id="span-3"></span>
  *   </div>
  * </div>
  * Selector `span` should return 3 span nodes in this order
  * span-1 -> span-2 -> span-3.
  *
  * 2.
  * <div> 
  *   <span id="span-1" class="note"></span>
  *   <span id="span-2"></span>
  *   <div>
  *     <span id="span-3"></span>
  *   </div>
  * </div>
  * Selector `.note` should return one span node with `note` class.
  *
  * 3.
  * <div> 
  *   <span id="span-1"></span>
  *   <span id="span-2"></span>
  *   <article>
  *     <div>
  *       <span id="span-3"></span>
  *     </div>
  *   </article>
  * </div>
  * Selector `div span` should return three span nodes in this order
  * span-1 -> span-2 -> span-3.
  * 
  * @param {string} the selector string.
  * @returns {Array} Array of descendent nodes.
  * @public
  */

  // Here we are suing Iterative approach for this....
  search(selector) {

    let search_result = [];
    let selectorType;

    try {
      if (selector == "") throw "empty";

      if (selector.charAt(0) === ".") {
        selectorType = "class";
      } else {
        selectorType = "tag";
      }
    } catch (err) {
      console.log("Empty");
    }


    search_result = this.traverse(this, selectorType, selector, search_result);
    return search_result;
  }

  traverse(node, type, selector, search_result) {
    try {
      if (type === "tag") {
        if (node.tag === selector && node.id != this.id) {
          search_result.push(node.id);
        }
      } else if (node.classes.includes(selector.substring(1)) && node.id != this.id) {
        search_result.push(node.id);
      }
      if (this.children.length > 0) {
        node.children.forEach(child => {
          this.traverse(child, type, selector, search_result);
        });
      }
      return search_result;
    } catch {
      console.log("Please enter a Tag or a Class as an argument");
    }

  }

}
// Creating valiables...
let span_4 = new Node("span", "span-4", ["mania"], []);
let span_5 = new Node("span", "span-5", ["note", "mania"], []);
let span_6 = new Node("span", "span-6", ["randomSpan"], []);
let divNode4 = new Node("div", "div-4", [], [span_4, span_5]);

let lable = new Node("label", "lbl-1", [], []);
let section_node = new Node("section", "sec-1", [], [lable]);
let divNode3 = new Node("div", "div-3", ["subContainer2"], [section_node]);
let span_3 = new Node("span", "span-3", ["sub1-span3"], []);
let p1 = new Node("p", "para-1", ["sub1-p1", "note"], []);
let divNode2 = new Node("div", "div-2", ["subContainer1"], [span_3, p1]);
let span_2 = new Node("span", "span-2", [], []);
let span_1 = new Node("span", "span-1", ["note"], []);
let divNode1 = new Node("div", "div-1", ["mainContainer"], [span_1, span_2, divNode2, divNode3, divNode4]);
let body = new Node("body", "content", [], [divNode1, span_6]);
console.log(body)

console.log("Started...");

// Test case 1 -
console.log(" divNode1.search(span) ");
console.log(divNode1.search("span"));

// Test case 2 -
console.log("divNode1.search(.note)");
console.log(divNode1.search(".note"));

// Test case 3 -
console.log("divNode1.search(label)");
console.log(divNode1.search("label"));

 

// Test case 4 -
console.log("p1.search(note)");
console.log(p1.search(".note"));

 

// Test case 5 -
console.log("divNode1.search(div)");
console.log(divNode1.search("div"));

// Test case 6 -
console.log("randomNode.search()");
console.log(span_6.search("div"));

// Test case 7 -
console.log("divNode2.search(section)");
console.log(divNode2.search("section"));

// Test case 8 -
console.log("body.search()");
console.log(body.search());

// Error conditions need to be handled

// invalid input need to be handled

 

// Test case 9 -
console.log("body.search(section)");
console.log(body.search("section"));

 

// Test case 10 -
console.log("body.search(div span)");
console.log(body.search("div span"));
